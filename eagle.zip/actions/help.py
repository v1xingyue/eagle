#coding=utf-8

import eagle_lib.printex as printex

def index(*args,**kwargs):
    printex.printLogo()